import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from wordcloud import WordCloud, STOPWORDS
from faker import Faker
import random

st.set_page_config(page_title="🌦 Monsoon Tweet Sentiment ", layout="wide")
st.title("🌦 Monsoon Tweet Sentiment Analysis")


st.markdown("""
    <style>
    .main { background-color: #f8f9fa; }
    h1 { color: #2c3e50; }
    .stMetric { background-color: #ffffff; border-radius: 10px; padding: 10px; }
    </style>
""", unsafe_allow_html=True)

st.sidebar.header("⚙️ Filters & Settings")

num_tweets = st.sidebar.slider("Number of tweets to generate:", 50, 500, 200)
selected_states = st.sidebar.multiselect(
    "Select States:",
    ["Andhra Pradesh", "Telangana", "Karnataka", "Maharashtra"],
    default=["Andhra Pradesh", "Telangana", "Karnataka", "Maharashtra"]
)
selected_sentiments = st.sidebar.multiselect(
    "Select Sentiments:",
    ["Positive", "Neutral", "Negative"],
    default=["Positive", "Neutral", "Negative"]
)
wordcloud_max_words = st.sidebar.slider("Max words in Word Cloud:", 50, 300, 100)
date_range_input = st.sidebar.date_input(
    "Select Date Range:",
    [pd.to_datetime("2025-06-01"), pd.to_datetime("2025-09-30")]
)

fake = Faker("en_IN")

state_districts = {
    "Andhra Pradesh": ["Visakhapatnam", "Vijayawada", "Guntur", "Kurnool"],
    "Telangana": ["Hyderabad", "Warangal", "Karimnagar", "Nizamabad"],
    "Karnataka": ["Bengaluru", "Mysuru", "Mangalore", "Hubli"],
    "Maharashtra": ["Mumbai", "Pune", "Nagpur", "Nashik"]
}

sentiments = ["Positive", "Neutral", "Negative"]
rain_keywords = ["rain", "rains", "downpour", "shower", "monsoon", "storm", "flood", "drizzle"]
date_range = pd.date_range(start="2025-06-01", end="2025-09-30")

data = []
for _ in range(num_tweets):
    state = random.choice(list(state_districts.keys()))
    district = random.choice(state_districts[state])
    tweet_text = fake.sentence(nb_words=random.randint(5, 15))
    if random.random() < 0.5:
        tweet_text += " " + random.choice(rain_keywords)
    sentiment = random.choice(sentiments)
    date = random.choice(date_range)
    data.append([state, district, tweet_text, sentiment, date])

df = pd.DataFrame(data, columns=["State", "District", "Tweet", "Monsoon_Sentiment", "Date"])


df_filtered = df[
    (df["State"].isin(selected_states)) &
    (df["Monsoon_Sentiment"].isin(selected_sentiments)) &
    (df["Date"].between(pd.to_datetime(date_range_input[0]), pd.to_datetime(date_range_input[1])))
]

st.success(f"Showing {len(df_filtered)} filtered tweets!")
st.dataframe(df_filtered.head(20))


st.download_button(
    label="📥 Download Filtered Data as CSV",
    data=df_filtered.to_csv(index=False).encode("utf-8"),
    file_name="monsoon_sentiment_filtered.csv",
    mime="text/csv"
)

st.subheader("📊 Key Metrics")
col1, col2, col3, col4 = st.columns(4)

col1.metric("Total Tweets", len(df_filtered))
col2.metric("Positive Tweets", len(df_filtered[df_filtered["Monsoon_Sentiment"] == "Positive"]))
col3.metric("Negative Tweets", len(df_filtered[df_filtered["Monsoon_Sentiment"] == "Negative"]))
col4.metric("Neutral Tweets", len(df_filtered[df_filtered["Monsoon_Sentiment"] == "Neutral"]))

st.subheader("☔ Rain-Related Word Cloud")
rain_tweets = df_filtered[df_filtered["Tweet"].str.contains('|'.join(rain_keywords), case=False, na=False)]

if not rain_tweets.empty:
    text = " ".join(tweet for tweet in rain_tweets["Tweet"])
    wordcloud = WordCloud(
        width=800, height=400, background_color='white',
        stopwords=STOPWORDS, max_words=wordcloud_max_words, colormap="viridis"
    ).generate(text)

    fig_wc, ax_wc = plt.subplots(figsize=(10, 5))
    ax_wc.imshow(wordcloud, interpolation="bilinear")
    ax_wc.axis("off")
    st.pyplot(fig_wc)
else:
    st.info("No rain-related tweets found in filtered data.")

st.subheader("📈 Sentiment Charts")
col1, col2 = st.columns(2)


with col1:
    sentiment_counts = df_filtered["Monsoon_Sentiment"].value_counts()
    fig1, ax1 = plt.subplots()
    ax1.pie(sentiment_counts, labels=sentiment_counts.index,
            autopct='%1.1f%%', startangle=90, wedgeprops={'edgecolor': 'black'})
    ax1.axis('equal')
    st.pyplot(fig1)


with col2:
    fig2, ax2 = plt.subplots(figsize=(6, 4))
    sns.countplot(x="Monsoon_Sentiment", data=df_filtered, palette="Set2", ax=ax2)
    for p in ax2.patches:
        height = p.get_height()
        ax2.annotate(f'{height}', (p.get_x() + p.get_width() / 2., height),
                     ha='center', va='bottom', fontsize=11)
    st.pyplot(fig2)

st.subheader("📉 Sentiment Trends Over Time")
df_trend = df_filtered.groupby(['Date', 'Monsoon_Sentiment']).size().reset_index(name='Count')
df_trend = df_trend.pivot(index='Date', columns='Monsoon_Sentiment', values='Count').fillna(0)

fig3, ax3 = plt.subplots(figsize=(12, 6))
df_trend.plot(ax=ax3, marker='o', linewidth=2)
plt.title("Monsoon Sentiment Trends Over Time", fontsize=16)
plt.xlabel("Date")
plt.ylabel("Number of Tweets")
plt.xticks(rotation=45)
plt.grid(True, linestyle='--', alpha=0.5)
plt.legend(title="Sentiment")
plt.tight_layout()
st.pyplot(fig3)

st.subheader("🗺 State-wise Sentiment Distribution")
fig4, ax4 = plt.subplots(figsize=(10, 5))
state_sentiment = df_filtered.groupby(["State", "Monsoon_Sentiment"]).size().unstack().fillna(0)
state_sentiment.plot(kind="bar", stacked=True, ax=ax4, colormap="tab20c")
plt.title("State-wise Sentiment Distribution")
plt.xlabel("State")
plt.ylabel("Tweet Count")
plt.xticks(rotation=45)
st.pyplot(fig4)
